import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./Paste.css";
import { removeFromPastes } from "../redux/pasteSlice";
import toast from "react-hot-toast";
import { Eye, Edit, Trash2, Copy, Share2, Search } from "lucide-react"; // Icons

const Paste = () => {
  const pastes = useSelector((state) => state.paste.pastes);
  const [searchTerm, setSearchTerm] = useState("");
  const dispatch = useDispatch();

  const filteredData = pastes.filter((paste) =>
    paste.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (pasteId) => {
    dispatch(removeFromPastes(pasteId));
  };

  return (
    <div className="paste-container">
      <div className="search-wrapper">
        <Search size={20} />
        <input
          className="search-bar"
          type="search"
          placeholder="Search here"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="cards">
        {filteredData.length > 0 &&
          filteredData.map((paste) => (
            <div key={paste?._id} className="card">
              <div className="card-title">{paste.title}</div>
              <div className="card-content">{paste.content}</div>

              <div className="card-actions">
                <button className="btn" title="Edit">
                  <a href={`/?pasteId=${paste?._id}`}>
                    <Edit size={18} />
                  </a>
                </button>

                <button className="btn" title="View">
                  <a href={`/pastes/${paste?._id}`}>
                    <Eye size={18} />
                  </a>
                </button>

                <button
                  className="btn"
                  onClick={() => handleDelete(paste._id)}
                  title="Delete"
                >
                  <Trash2 size={18} />
                </button>

                <button
                  className="btn"
                  onClick={() => {
                    navigator.clipboard.writeText(paste?.content);
                    toast.success("Copied to Clipboard");
                  }}
                  title="Copy Content"
                >
                  <Copy size={18} />
                </button>

                <button
                  className="btn"
                  onClick={() => {
                    const url = `${window.location.origin}/pastes/${paste._id}`;
                    if (navigator.share) {
                      navigator
                        .share({
                          title: paste.title || "Shared Paste",
                          text: "Check out this paste!",
                          url: url,
                        })
                        .then(() => toast.success("Shared successfully!"))
                        .catch(() => toast.error("Share cancelled or failed"));
                    } else {
                      navigator.clipboard.writeText(url);
                      toast.success("Link copied to clipboard!");
                    }
                  }}
                  title="Share"
                >
                  <Share2 size={18} />
                </button>
              </div>

              <div className="created-at">
                {new Date(paste.createdAt).toLocaleString("en-US", {
                  month: "long", // e.g., July
                  day: "numeric", // e.g., 28
                  year: "numeric", // e.g., 2025
                  hour: "numeric", // e.g., 8
                  minute: "2-digit", // e.g., 09
                  second: "2-digit", // e.g., 33
                  hour12: true, // AM/PM format
                })}
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Paste;
