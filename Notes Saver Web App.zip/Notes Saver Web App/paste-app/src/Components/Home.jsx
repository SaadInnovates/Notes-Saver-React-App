import React, { useState, useEffect } from "react";
import "./Home.css";
import { useSearchParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addToPastes, updateToPastes } from "../redux/pasteSlice";

const Home = () => {
  const [title, setTitle] = useState("");
  const [value, setValue] = useState("");
  const [searchParams, setSearchParams] = useSearchParams();
  const pasteId = searchParams.get("pasteId");

  const dispatch = useDispatch();
  const allPastes = useSelector((state) => state.paste.pastes);

  useEffect(() => {
    if (pasteId) {
      const pasteSelected = allPastes.find((p) => p._id === pasteId);
      if (pasteSelected) {
        setTitle(pasteSelected.title);
        setValue(pasteSelected.content);
      }
    }
  }, [pasteId]);

  function createPaste() {
    const paste = {
      title,
      content: value,
      _id: pasteId || Date.now().toString(36),
      createdAt: new Date().toISOString(),
    };

    if (pasteId) dispatch(updateToPastes(paste));
    else dispatch(addToPastes(paste));

    setTitle("");
    setValue("");
    setSearchParams({});
  }

  return (
    <div className="home-container">
      <div className="home-display">
        <input
          className="input-title form-style"
          type="text"
          placeholder="Enter title here"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <button className="btn-submit" onClick={createPaste}>
          {pasteId ? "Update My Paste" : "Create My Paste"}
        </button>
      </div>

      <div className="text-area-wrapper">
        <div className="dots">
          <span className="dot red" />
          <span className="dot yellow" />
          <span className="dot green" />
        </div>
        <textarea
          className="text-area-style"
          placeholder="Enter content here"
          value={value}
          rows={18}
          onChange={(e) => setValue(e.target.value)}
        />
      </div>
    </div>
  );
};

export default Home;
