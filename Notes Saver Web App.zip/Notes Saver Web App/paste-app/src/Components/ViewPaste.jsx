import React, { useRef } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import "./ViewPaste.css";
import { Copy } from "lucide-react";

const ViewPaste = () => {
  const { id } = useParams();
  const allPastes = useSelector((state) => state.paste.pastes);
  const textareaRef = useRef(null);

  const pasteSelected = allPastes.find((p) => p?._id === id);

  if (!pasteSelected) return <p>Paste not found!</p>;

  const handleCopy = () => {
    navigator.clipboard.writeText(pasteSelected.content);
    alert("Content copied to clipboard!");
  };

  return (
    <div className="view-paste-container">
      <div className="home-display">
        <input
          className="input-title form-style"
          type="text"
          value={pasteSelected.title}
          disabled
        />
      </div>

      <div className="textarea-wrapper">
        <div className="text-area-header">
          <div className="window-controls">
            <span className="dot red"></span>
            <span className="dot yellow"></span>
            <span className="dot green"></span>
          </div>
          <button className="copy-button" onClick={handleCopy}>
            <Copy size={18} />
          </button>
        </div>

        <textarea
          className="text-area-style"
          placeholder="enter content here"
          disabled
          value={pasteSelected.content}
          rows={20}
        ></textarea>
      </div>
    </div>
  );
};

export default ViewPaste;
